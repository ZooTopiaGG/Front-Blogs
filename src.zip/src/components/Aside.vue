<template>
  <aside class="aside">
    <!-- 右一 -->
    <div class="box bgbox job">
      <h1>工作经历</h1>
      <div>
        我是2016年毕业的本科生，我从2015年8月初就开始工作，第一家公司是在四川成都的四凯科技有限公司实习，工作了2个月。然后去了第二家公司九益恒泰科技有限公司，工作到至今，负责web前端开发，高效的完成了公司的给的任务并在空余的时间进行自学新的前端技术等。
      </div>
      <div class="second-box">
        <img class='maps' src="../assets/images/maps.png">
      </div>
    </div>
    <!-- 右二 -->
    <div class="second-box bgbox about">
      <div>
        <img class="avatar" src="../assets/images/23115938.jpg" alt="avatar">
      </div>
      <div class="con-title">关于我</div>
      <div class="con">
        大家好！我是邓鹏，2016年毕业后从事前端开发，NodeJs开发，這是我的一个个人网站，到目前已经一年多了，我非常开心能从事這个行业，因为在這里我找到了每天的充实感以及成就感！我很爱這份职业，如果有一天，当我写不懂代码的时候，我相信我还是会坚持把這个网站做好，虽然现在刚刚开始，這个网站整体而言不太成熟，但是我相信终有一天，這个网站会被很多相同职业的伙伴喜欢，這里包含了技术、阅读、音乐以及个人动态等很多东西。加油！
      </div>
    </div>
  </aside>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  name: 'navs',
  data() {
    return {
      activeIndex: '1',
      show: false,
      res: {}
    };
  },
  computed: {
    ...mapGetters ([
      'GET_NAV_SHOW',
      'GET_IS_HOME',
      'GET_LOGIN_STATUS'
    ])
  },
  methods: {
    handleSelect(key, keyPath) {
      console.log(key, keyPath);
    },
    signout () {
      window.localStorage.clear();
      this.show = false;
      this.$store.dispatch('NO_LOGIN', null)
    },
    toinfo () {
      this.show = false;
      this.$router.push({ name: 'info', params: { userid: this.GET_LOGIN_STATUS.id } })
    }
  },
  mounted () {
    sr.reveal(document.querySelectorAll('.second-box'))
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.avatar {
  width: 160px;
  height: 160px;
  border-radius: 100%; 
  margin-bottom: 15px; 
}
.second-box img, .second-box a{
  display:block;
  color: #fff;
}
.second-box .bg{
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  right: 0;
  background: rgba(0, 0, 0, 0);
  -webkit-transition: all .4s;
  --moz-transition: all .4s;
  -o-transition: all .4s;
  transition: all .4s;
  z-index:7;
}
.job {
  color: #555;
  font-size: 15px;
  line-height: 1.7;
  padding: 40px 20px;
  text-align: center;
}
.job h1{
  color: #18aacf;
  font-size: 42px;
  margin: 20px 0 20px;
}
.job img{
  margin: 20px auto 0;
}
.skillsBox {
  width:100%; 
  height:160px; 
  font-size: 24px;
  background: url(http://api.55lover.com/static/web/uploads/9fdd4722137ce.jpg) no-repeat; 
  background-size: auto;
  color: #fff;
}
.skillsBox img{
  margin:0 auto 20px;
}
.skillsBox aside {
  font-size: 48px;
}
.about {
  text-align: center;
  padding:40px 20px;
}
.about img{
  margin: auto;
}
.con-title {
  color: #18aacf;
  font-size: 42px;
  margin: 20px 0 20px;
}
.maps {
  width: 100%;
  height: 100%;
}

</style>

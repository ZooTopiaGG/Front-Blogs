//中间件文件
import Vue from 'vue'

export default new Vue;

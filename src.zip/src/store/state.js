export default {
  navShow: true,
  isHome: false,
  footerShow: true,
  isLogin: {},
  isPlay: false
}
